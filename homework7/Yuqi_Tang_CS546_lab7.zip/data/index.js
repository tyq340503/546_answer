const postData = require("./post");
//const userData = require("./users");

module.exports = {
    //users: userData
    posts: postData
};