const calculator = require("./calculator");

module.exports = {
  calculator: calculator
};
