const check = require("./check");

module.exports = {
  check: check
};
