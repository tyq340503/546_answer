(function ($) {

    var myNewTaskForm = $("#new-item-form"),
      newNameInput = $("#new-task-name"),
      //newDecriptionArea = $("#new-task-description"),
      todoArea = $("#attempts");

    //   $("#new-item-form").on('click',function(){
    //       alert('1');
    //   })
  
      myNewTaskForm.submit(function(event) {
        debugger;
        event.preventDefault();
        var newName = newNameInput.val();
        //var newDescription = newDecriptionArea.val();
        //var newContent = $("#new-content");
    
        if (newName) {
          var useJson = false;
          if (useJson) {
            var requestConfig = {
              method: "POST",
              url: "/calculator/addto",
              contentType: "application/json",
              data: JSON.stringify({
                name: newName
              })
            };
    
            $.ajax(requestConfig).then(function(responseMessage) {
              console.log(responseMessage);
              // newContent.html(responseMessage.message);
              // salert("Data Saved: " + msg);
            });
          } else {
            var requestConfig = {
              method: "POST",
              url: "/calculator/addto.html",
              contentType: "application/json",
              data: JSON.stringify({
                name: newName
              })
            };
    
            $.ajax(requestConfig).then(function(responseMessage) {
              console.log(responseMessage);
              var newElement = $(responseMessage);
              //bindEventsToTodoItem(newElement);
    
              todoArea.append(newElement);
            });
          }
        }
      });
  })(window.jQuery);
  